Config = {}

Config.discord_webhook = "https://discord.com/api/webhooks/ID/TOKEN"

Config.prices = {
    cannabis = 100,
    coke = 500,
    meth = 400
}

Config.sellLocations = {
    {x = -1234.56, y = -456.78, z = 35.67, label = "Sælgerpunkt 1"},
    {x = 234.56, y = -987.65, z = 30.12, label = "Sælgerpunkt 2"}
}

Config.sql_table = "drug_sales"

Config.sellCooldown = 10
