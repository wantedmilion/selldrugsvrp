local Tunnel = module("vrp", "lib/Tunnel")
local Proxy = module("vrp", "lib/Proxy")
vRP = Proxy.getInterface("vRP")
vRPclient = Tunnel.getInterface("vRP","sell_drugs_vrp")

local sold_recent = {}

RegisterNetEvent('selldrugs:callback:getInventory')
AddEventHandler('selldrugs:callback:getInventory', function(cb)
    local src = source
    local user_id = vRP.getUserId({src})
    local inv = {}
    if user_id then
        local inventory = vRP.getInventory({user_id}) or {}
        for k,v in pairs(inventory) do
            if v.amount and Config.prices[k] then
                inv[k] = {label = v.name or k, amount = v.amount}
            end
        end
    end
    cb(inv)
end)

RegisterServerEvent('selldrugs:server:trySell')
AddEventHandler('selldrugs:server:trySell', function(item, amount)
    local src = source
    local user_id = vRP.getUserId({src})
    if not user_id then return end

    if sold_recent[user_id] and (os.time() - sold_recent[user_id]) < Config.sellCooldown then
        TriggerClientEvent('chat:addMessage', src, {args = {"Salg", "Du skal vente lidt før du kan sælge igen."}})
        return
    end

    local price_per = Config.prices[item] or 0
    local total_price = price_per * amount

    local removed = vRP.tryGetInventoryItem({user_id, item, amount, true})
    if removed then
        vRP.giveMoney({user_id, total_price})
        sold_recent[user_id] = os.time()

        local query = string.format("INSERT INTO %s (user_id, drug, amount, price, timestamp) VALUES (%d, '%s', %d, %d, %d)",
            Config.sql_table, user_id, item, amount, total_price, os.time())
        if MySQL and MySQL.Async and MySQL.Async.execute then
            MySQL.Async.execute(query, {}, function(rowsChanged) end)
        else
            print("[sell_drugs_vrp] MySQL driver ikke fundet — husk at køre SQL manuelt eller tilpasse.")
        end

        if Config.discord_webhook and Config.discord_webhook ~= "" then
            local embeds = {{
                title = "Narkosalg",
                fields = {
                    {name = "Spiller ID", value = tostring(user_id), inline = true},
                    {name = "Item", value = tostring(item), inline = true},
                    {name = "Antal", value = tostring(amount), inline = true},
                    {name = "Total pris", value = tostring(total_price), inline = true}
                },
                timestamp = os.date("!%Y-%m-%dT%H:%M:%SZ")
            }}
            PerformHttpRequest(Config.discord_webhook, function(err, text, headers) end, 'POST', json.encode({username = "SalgBot", embeds = embeds}), {['Content-Type'] = 'application/json'})
        end

        TriggerClientEvent('chat:addMessage', src, {args = {"Salg", "Du solgte " .. amount .. "x " .. item .. " for " .. total_price .. "₵"}})
    else
        TriggerClientEvent('chat:addMessage', src, {args = {"Salg", "Du har ikke nok af dette item."}})
    end
end)
