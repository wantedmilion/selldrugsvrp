local sellCooldown = false

Citizen.CreateThread(function()
    Wait(1000)
    for _, loc in ipairs(Config.sellLocations) do
        if exports and exports.ox_target and exports.ox_target.addBox then
            exports.ox_target:addBox({
                coords = vec3(loc.x, loc.y, loc.z),
                size = vec3(1.2, 1.2, 1.2),
                rotation = vec3(0.0, 0.0, 0.0),
                debug = false,
                options = {
                    {
                        name = 'sell_drugs_' .. loc.label,
                        event = 'selldrugs:client:sellMenu',
                        icon = 'fa-solid fa-handshake',
                        label = 'Sælg narkotika: ' .. (loc.label or ''),
                    }
                }
            })
        else

            if exports.ox_target and exports.ox_target:addSphere then
                exports.ox_target:addSphere({
                    coords = vec3(loc.x, loc.y, loc.z),
                    radius = 1.25,
                    options = {
                        {
                            name = 'sell_drugs_' .. loc.label,
                            event = 'selldrugs:client:sellMenu',
                            icon = 'fa-solid fa-handshake',
                            label = 'Sælg narkotika: ' .. (loc.label or ''),
                        }
                    }
                })
            else
                print("ox_target ikke fundet eller ukendt API — tilpas client.lua for din version.")
            end
        end
    end
end)

RegisterNetEvent('selldrugs:client:sellMenu', function()
    if sellCooldown then
        lib.notify({title = "Salg", description = "Du skal vente lidt før du kan sælge igen.", type = 'error'})
        return
    end

    lib.callback('selldrugs:callback:getInventory', false, function(items)
        local options = {}
        for name, info in pairs(items) do
            table.insert(options, {
                title = info.label .. " x" .. info.amount,
                description = "Pris pr. enhed: " .. (Config.prices[name] or 0) .. "₵",
                event = 'selldrugs:client:confirmSell',
                args = {item = name, amount = info.amount}
            })
        end

        if #options == 0 then
            lib.notify({title = "Salg", description = "Du har intet at sælge.", type = 'error'})
            return
        end

        lib.registerContext({
            id = 'sell_drugs_menu',
            title = 'Sælg narkotika',
            options = options
        })
        lib.showContext('sell_drugs_menu')
    end)
end)

RegisterNetEvent('selldrugs:client:confirmSell', function(data)
    local item = data.item
    local amount = data.amount
    local price = Config.prices[item] or 0
    local toSell = amount
    if toSell <= 0 then
        lib.notify({title = "Salg", description = "Ugyldigt antal.", type = 'error'})
        return
    end

    TriggerServerEvent('selldrugs:server:trySell', item, toSell)
    sellCooldown = true
    SetTimeout(Config.sellCooldown * 1000, function() sellCooldown = false end)
end)

Citizen.CreateThread(function()
    for _, loc in ipairs(Config.sellLocations) do
        local blip = AddBlipForCoord(loc.x, loc.y, loc.z)
        SetBlipSprite(blip, 140)
        SetBlipScale(blip, 0.6)
        SetBlipAsShortRange(blip, true)
        BeginTextCommandSetBlipName("STRING")
        AddTextComponentString(loc.label or "Sælgerpunkt")
        EndTextCommandSetBlipName(blip)
    end
end)
