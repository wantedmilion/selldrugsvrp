CREATE TABLE IF NOT EXISTS `drug_sales` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `user_id` INT NOT NULL,
  `drug` VARCHAR(100) NOT NULL,
  `amount` INT NOT NULL,
  `price` INT NOT NULL,
  `timestamp` INT NOT NULL,
  PRIMARY KEY (`id`),
  INDEX (`user_id`),
  INDEX (`timestamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
