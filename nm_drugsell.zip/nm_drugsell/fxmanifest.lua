fx_version 'cerulean'
game 'gta5'

author 'NM Store'
description 'vRP drug selling script with ox_target, ox_lib, Discord webhook and SQL logging'
version '1.0.0'

shared_script 'config.lua'
client_script 'client.lua'
server_script 'server.lua'

-- Hvis du bruger en nyere ressourcemanager eller fxmanifest struktur, tilpas efter behov.
